Place whatsapp-float.png (your provided image) here. The app references /images/whatsapp-float.png by default.
